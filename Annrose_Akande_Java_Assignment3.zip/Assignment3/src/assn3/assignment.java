/*
Name: Annrose Akande
Student Number: 041169608
Professor: Leanne Seaward
///Due Date: 11-04-2025
 */

package assn3;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * The Assignment3 class is the main driver class for the Bread Recipe Manager.
 * It handles user interaction and menu navigation.
 */
public class assignment {
    private static RecipeManager recipeManager;
    private static Scanner scanner;

    /**
     * Main method that starts the program.
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        recipeManager = new RecipeManager();
        scanner = new Scanner(System.in);
        
        System.out.println("Welcome to Algonquin College's recipe manager.");
        printMenu();
        
        boolean running = true;
        while (running) {
            System.out.print("Please enter your choice: ");
            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 0:
                        printMenu();
                        break;
                    case 1:
                        showAvailableRecipes();
                        break;
                    case 2:
                        createShoppingList();
                        break;
                    case 3:
                        printShoppingList();
                        break;
                    case 4:
                        running = false;
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 0 and 4.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please only type digits.\nValid input are digits from 0 to 4.");
                scanner.nextLine(); // Clear invalid input
            }
        }
        scanner.close();
    }

    /**
     * Prints the main menu options.
     */
    private static void printMenu() {
        System.out.println("Please select one of the following options:");
        System.out.println("1. Show available recipes.");
        System.out.println("2. Create Shopping List.");
        System.out.println("3. Print Shopping List.");
        System.out.println("4. Quit Program.");
        System.out.println("0. to reprint this menu.");
    }

    /**
     * Displays all available recipes with their numbers.
     */
    private static void showAvailableRecipes() {
        List<Recipe> recipes = recipeManager.getRecipes();
        System.out.println("Available Recipes:");
        for (int i = 0; i < recipes.size(); i++) {
            System.out.println((i + 1) + ". " + recipes.get(i).getName());
        }
    }

    /**
     * Handles the process of creating a shopping list by ordering recipes.
     */
    private static void createShoppingList() {
        showAvailableRecipes();
        System.out.print("Which bread would you like? ");
        
        try {
            int breadChoice = scanner.nextInt() - 1;
            scanner.nextLine(); // Consume newline
            
            if (breadChoice < 0 || breadChoice >= recipeManager.getRecipes().size()) {
                System.out.println("Invalid bread selection. Please try again.");
                return;
            }
            
            System.out.print("How much of this bread would you like? ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            if (quantity <= 0) {
                System.out.println("Quantity must be positive. Order not added.");
                return;
            }
            
            if (recipeManager.addRecipeOrder(breadChoice, quantity)) {
                System.out.println("Order added successfully.");
            } else {
                System.out.println("Failed to add order. Please try again.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Please only type digits.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    /**
     * Prints the shopping list and optionally saves it to a file.
     */
    private static void printShoppingList() {
        String shoppingList = recipeManager.generateShoppingList();
        System.out.println(shoppingList);
        
        if (!shoppingList.startsWith("No recipes")) {
            System.out.print("Do you want to save this list (Y/n)? ");
            String saveChoice = scanner.nextLine().trim();
            
            if (saveChoice.equalsIgnoreCase("Y") || saveChoice.isEmpty()) {
                if (recipeManager.saveShoppingList(shoppingList)) {
                    System.out.println("Shopping list saved to " + RecipeManager.SHOPPING_LIST_FILE);
                } else {
                    System.out.println("Failed to save shopping list.");
                }
            }
        }
    }
}