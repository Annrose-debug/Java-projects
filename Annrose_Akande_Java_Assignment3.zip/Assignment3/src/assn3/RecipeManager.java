/*
Name: Annrose Akande
Student Number: 041169608
Professor: Leanne Seaward
///Due Date: 11-04-2025
 */
package assn3;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The RecipeManager class manages the list of recipes and handles file operations.
 */
public class RecipeManager {
    private List<Recipe> recipes;
    private static final String RECIPE_FILE = "recipelist1.txt";  // Changed filename here
    static final String SHOPPING_LIST_FILE = "shoppinglist.txt";

    /**
     * Constructor for RecipeManager.
     * Initializes the recipe list and loads recipes from file.
     */
    public RecipeManager() {
        recipes = new ArrayList<>();
        loadRecipes();
    }

    /**
     * Loads recipes from the recipelist1.txt file.
     * Handles file reading and parsing of recipe data.
     */
    private void loadRecipes() {
        File recipeFile = new File(RECIPE_FILE);
        System.out.println("Looking for recipe file at: " + recipeFile.getAbsolutePath());  // Debug line
        
        try (Scanner fileScanner = new Scanner(recipeFile)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine().trim();
                if (line.startsWith("Recipe ")) {
                    String recipeName = line.substring(7).trim();
                    Recipe recipe = new Recipe(recipeName);
                    
                    // Read the next 5 lines for ingredients
                    for (int i = 0; i < 5; i++) {
                        if (!fileScanner.hasNextLine()) break;
                        String ingredientLine = fileScanner.nextLine().trim();
                        if (ingredientLine.isEmpty()) continue;
                        
                        String[] parts = ingredientLine.split(" ");
                        if (parts.length < 2) continue;
                        
                        String ingredient = parts[0].trim();
                        double amount = Double.parseDouble(parts[1].trim());
                        
                        switch (ingredient.toLowerCase()) {
                            case "eggs":
                                recipe.setEggs(amount);
                                break;
                            case "yeast":
                                recipe.setYeast(amount);
                                break;
                            case "flour":
                                recipe.setFlour(amount);
                                break;
                            case "sugar":
                                recipe.setSugar(amount);
                                break;
                            case "butter":
                                recipe.setButter(amount);
                                break;
                        }
                    }
                    recipes.add(recipe);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Recipe file not found: " + recipeFile.getAbsolutePath());
            System.err.println("Please ensure recipelist1.txt is in the correct location.");
        } catch (Exception e) {
            System.err.println("Error loading recipes: " + e.getMessage());
        }
    }


    /**
     * Gets the list of all recipes.
     * @return List of Recipe objects
     */
    public List<Recipe> getRecipes() {
        return recipes;
    }

    /**
     * Gets a specific recipe by index.
     * @param index The index of the recipe
     * @return The Recipe object, or null if index is invalid
     */
    public Recipe getRecipe(int index) {
        if (index >= 0 && index < recipes.size()) {
            return recipes.get(index);
        }
        return null;
    }

    /**
     * Adds to the quantity of a specific recipe.
     * @param index The index of the recipe
     * @param quantity The quantity to add
     * @return true if successful, false if index is invalid or quantity is negative
     */
    public boolean addRecipeOrder(int index, int quantity) {
        if (index < 0 || index >= recipes.size() || quantity <= 0) {
            return false;
        }
        Recipe recipe = recipes.get(index);
        recipe.addQuantity(quantity);
        return true;
    }

    /**
     * Generates a shopping list string based on ordered recipes.
     * @return The formatted shopping list string
     */
    public String generateShoppingList() {
        StringBuilder sb = new StringBuilder();
        double totalEggs = 0, totalYeast = 0, totalFlour = 0, totalSugar = 0, totalButter = 0;
        boolean hasOrders = false;

        // Build the list of ordered recipes
        for (Recipe recipe : recipes) {
            if (recipe.getQuantity() > 0) {
                hasOrders = true;
                sb.append(recipe.getQuantity()).append(" ")
                  .append(recipe.getName()).append(" loaf/loaves.\n");
                
                totalEggs += recipe.getEggs() * recipe.getQuantity();
                totalYeast += recipe.getYeast() * recipe.getQuantity();
                totalFlour += recipe.getFlour() * recipe.getQuantity();
                totalSugar += recipe.getSugar() * recipe.getQuantity();
                totalButter += recipe.getButter() * recipe.getQuantity();
            }
        }

        if (!hasOrders) {
            return "No recipes have been ordered yet.\n";
        }

        sb.append("\nYou will need a total of:\n");
        
        if (totalYeast > 0) sb.append(String.format("%.0f grams of yeast\n", totalYeast));
        if (totalFlour > 0) sb.append(String.format("%.0f grams of flour\n", totalFlour));
        if (totalSugar > 0) sb.append(String.format("%.0f grams of sugar\n", totalSugar));
        if (totalEggs > 0) sb.append(String.format("%.0f egg(s)\n", totalEggs));
        if (totalButter > 0) sb.append(String.format("%.0f grams of butter\n", totalButter));

        return sb.toString();
    }

    /**
     * Saves the shopping list to a file.
     * @param shoppingList The shopping list content to save
     * @return true if successful, false otherwise
     */
    public boolean saveShoppingList(String shoppingList) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(SHOPPING_LIST_FILE))) {
            writer.print(shoppingList);
            return true;
        } catch (IOException e) {
            System.err.println("Error saving shopping list: " + e.getMessage());
            return false;
            
      
        }
    }
    
}