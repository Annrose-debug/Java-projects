/*
Name: Annrose Akande
Student Number: 041169608
Professor: Leanne Seaward
///Due Date: 11-04-2025
 */


package assn3;

/**
 * The Recipe class represents a bread recipe with its ingredients.
 * It contains getters and setters for all recipe properties.
 */
public class Recipe {
    private String name;
    private double eggs;
    private double yeast;
    private double flour;
    private double sugar;
    private double butter;
    private int quantity;

    /**
     * Constructor for Recipe class.
     * @param name The name of the bread recipe
     */
    public Recipe(String name) {
        this.name = name;
        this.quantity = 0;
    }

    // Getters and setters for all fields
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getEggs() {
        return eggs;
    }

    public void setEggs(double eggs) {
        this.eggs = eggs;
    }

    public double getYeast() {
        return yeast;
    }

    public void setYeast(double yeast) {
        this.yeast = yeast;
    }

    public double getFlour() {
        return flour;
    }

    public void setFlour(double flour) {
        this.flour = flour;
    }

    public double getSugar() {
        return sugar;
    }

    public void setSugar(double sugar) {
        this.sugar = sugar;
    }

    public double getButter() {
        return butter;
    }

    public void setButter(double butter) {
        this.butter = butter;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Adds to the current quantity of this recipe.
     * @param amount The amount to add (must be positive)
     */
    public void addQuantity(int amount) {
        if (amount > 0) {
            this.quantity += amount;
        }
    }
}